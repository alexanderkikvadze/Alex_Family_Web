# Alex Family Web

### Test Web Page projects for Learning purpose

## Task
Build firs application using HTML, CSS, JavaScript Technology 

## Criteria
Creater Web site with family information and Photos.
First Photos was added about Racha/znakva

##Summary
This app was building using HTML, CSS, JavaScript Technologies. 
This is first HTML, CSS, JavaScript application what i created for learning purpose.


## Functionality
informationa about my family and racha willbe displayed in the web site

## Design

## Run Locally

## Tech Stack
* HTML 
* CSS
* JavaScript
* will be updated
